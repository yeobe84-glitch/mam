Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & "run_sandsu_v59.cmd" & chr(34), 0
Set WshShell = Nothing
