from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os
import sys
import json
import shutil
import threading
import time
import urllib.request
import urllib.parse
from datetime import datetime
from urllib.parse import urlparse

PORT = 8027
ROOT = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__))
TARGET = 'sandsu_attendance_ui_exam_message_bookfocus_v59.html'
DATA_DIR = os.path.join(ROOT, 'data')
DATA_FILE = os.path.join(DATA_DIR, 'academy_data.json')
BACKUP_DIR = os.path.join(DATA_DIR, 'backups')
THEMES_DIR = os.path.join(ROOT, 'themes')
MAX_BACKUPS = 14
ONLINE_CONFIG_FILE = os.path.join(DATA_DIR, 'online_config.json')
DEFAULT_ONLINE_URL = 'https://script.google.com/macros/s/AKfycbyQQLYZ42a-3Uwyvtx_gSOgA11uIGTiygDY1sV4WyUfd-f9YgRKSf9tvXN6cZBNKs27vw/exec'
ONLINE_UPLOAD_DELAY_SECONDS = 0
ONLINE_TIMEOUT_SECONDS = 12
ONLINE_TEACHERS = {'yeop', 'yeom', 'yeong'}
_online_lock = threading.Lock()
_online_timer = None
_online_latest_payload = None
_online_last_status = {'ok': None, 'message': '온라인 저장 대기', 'uploaded_at': ''}
_remote_sync_revision = 0
_remote_sync_lock = threading.Lock()
_remote_sync_stop = threading.Event()
_known_server_version = 0
_local_dirty = False
_last_remote_signal = 0
REMOTE_POLL_SECONDS = 2


def ensure_data_dirs():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)
    os.makedirs(THEMES_DIR, exist_ok=True)


def cleanup_old_backups():
    try:
        files = []
        for name in os.listdir(BACKUP_DIR):
            if not name.lower().endswith('.json'):
                continue
            path = os.path.join(BACKUP_DIR, name)
            if os.path.isfile(path):
                files.append((os.path.getmtime(path), path))
        files.sort(reverse=True)
        for _, old_path in files[MAX_BACKUPS:]:
            try:
                os.remove(old_path)
            except Exception:
                pass
    except Exception:
        pass


def create_startup_backup_once():
    """Create at most one backup per day, only when the server starts.
    Auto-save calls never create additional backup files.
    """
    ensure_data_dirs()
    if not os.path.exists(DATA_FILE):
        cleanup_old_backups()
        return

    today = datetime.now().strftime('%Y-%m-%d')
    backup_file = os.path.join(BACKUP_DIR, f'academy_data_{today}.json')

    if not os.path.exists(backup_file):
        try:
            shutil.copy2(DATA_FILE, backup_file)
        except Exception:
            pass

    cleanup_old_backups()


def write_json_safely(payload):
    """Main save path: overwrite only academy_data.json.
    Auto-save cannot flood backups/.
    """
    ensure_data_dirs()
    tmp_file = DATA_FILE + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp_file, DATA_FILE)


def now_iso():
    return datetime.now().isoformat(timespec='seconds')


def parse_time_value(value):
    text = str(value or '').strip()
    if not text:
        return 0.0
    try:
        if text.endswith('Z'):
            text = text[:-1] + '+00:00'
        return datetime.fromisoformat(text).timestamp()
    except Exception:
        return 0.0


def get_payload_timestamp(payload, fallback_file=None):
    if isinstance(payload, dict):
        ts = parse_time_value(payload.get('updated_at'))
        if ts:
            return ts
    if fallback_file and os.path.exists(fallback_file):
        try:
            return os.path.getmtime(fallback_file)
        except Exception:
            pass
    return 0.0


def normalize_local_payload(payload):
    if not isinstance(payload, dict):
        payload = {'data': payload}
    try:
        payload['version'] = int(payload.get('version') or 0) + 1
    except Exception:
        payload['version'] = 1
    payload['updated_at'] = now_iso()
    return payload


def read_local_payload():
    if not os.path.exists(DATA_FILE):
        return None
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_online_config():
    ensure_data_dirs()
    cfg = {
        'enabled': True,
        'teacher': 'yeop',
        'base_url': DEFAULT_ONLINE_URL,
        'password': '',
        'last_remote_signal': 0,
        'last_online_revision': ''
    }
    try:
        if os.path.exists(ONLINE_CONFIG_FILE):
            with open(ONLINE_CONFIG_FILE, 'r', encoding='utf-8') as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                cfg.update(saved)
    except Exception:
        pass
    cfg['teacher'] = cfg.get('teacher') if cfg.get('teacher') in ONLINE_TEACHERS else 'yeop'
    cfg['base_url'] = str(cfg.get('base_url') or DEFAULT_ONLINE_URL).strip().rstrip('/')
    cfg['enabled'] = bool(cfg.get('enabled'))
    cfg['password'] = str(cfg.get('password') or '')
    return cfg


def save_online_config(cfg):
    ensure_data_dirs()
    current = load_online_config()
    incoming = cfg if isinstance(cfg, dict) else {}
    current['enabled'] = bool(incoming.get('enabled'))
    if 'last_online_revision' in incoming:
        current['last_online_revision'] = str(incoming.get('last_online_revision') or '')
    if 'last_remote_signal' in incoming:
        try:
            current['last_remote_signal'] = int(incoming.get('last_remote_signal') or 0)
        except Exception:
            current['last_remote_signal'] = 0
    current['teacher'] = incoming.get('teacher') if incoming.get('teacher') in ONLINE_TEACHERS else current.get('teacher', 'yeop')
    current['base_url'] = str(incoming.get('base_url') or current.get('base_url') or DEFAULT_ONLINE_URL).strip().rstrip('/')
    if 'password' in incoming:
        current['password'] = str(incoming.get('password') or '')
    tmp_file = ONLINE_CONFIG_FILE + '.tmp'
    with open(tmp_file, 'w', encoding='utf-8') as f:
        json.dump(current, f, ensure_ascii=False, indent=2)
    os.replace(tmp_file, ONLINE_CONFIG_FILE)
    return current


def public_online_config():
    cfg = load_online_config()
    return {
        'enabled': cfg.get('enabled', False),
        'teacher': cfg.get('teacher', 'yeop'),
        'base_url': cfg.get('base_url', DEFAULT_ONLINE_URL),
        'has_password': bool(cfg.get('password')),
        'last_status': dict(_online_last_status),
    }


def _http_request_json(url, payload=None, headers=None, method=None, timeout=ONLINE_TIMEOUT_SECONDS):
    data = None
    req_headers = dict(headers or {})
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        req_headers.setdefault('Content-Type', 'application/json;charset=UTF-8')
    req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as res:
        body = res.read().decode('utf-8', errors='replace')
        try:
            return res.status, json.loads(body) if body else {} , res.headers
        except Exception:
            return res.status, {'raw': body}, res.headers


def _drive_read(cfg):
    teacher = cfg.get('teacher') or 'yeop'
    url = (cfg.get('base_url') or DEFAULT_ONLINE_URL).rstrip('/') + '?teacher=' + urllib.parse.quote(teacher) + '&ts=' + str(int(time.time() * 1000))
    status, res, _ = _http_request_json(url, None, method='GET')
    if not (200 <= status < 300) or not isinstance(res, dict) or res.get('ok') is False:
        raise RuntimeError(str(res))
    data = res.get('data')
    if not isinstance(data, dict):
        raise RuntimeError('Google Drive 데이터 형식 오류')
    return data


def _sync_marker(payload):
    marker = payload.get('__sandsuSync') if isinstance(payload, dict) else None
    return marker if isinstance(marker, dict) else {}


def _clean_remote_payload(payload):
    if not isinstance(payload, dict):
        return payload
    cleaned = dict(payload)
    cleaned.pop('__sandsuSync', None)
    return cleaned


def _drive_write(cfg, payload, source):
    outgoing = dict(payload) if isinstance(payload, dict) else {'data': payload}
    outgoing['__sandsuSync'] = {
        'source': source,
        'revision': str(time.time_ns()),
        'saved_at': now_iso(),
    }
    status, res, _ = _http_request_json(
        cfg.get('base_url') or DEFAULT_ONLINE_URL,
        {'teacher': cfg.get('teacher') or 'yeop', 'data': outgoing},
        method='POST'
    )
    if not (200 <= status < 300) or not isinstance(res, dict) or res.get('ok') is False:
        raise RuntimeError(str(res))
    return outgoing['__sandsuSync']


def _login_cookie(base_url, password):
    form = urllib.parse.urlencode({'password': password}).encode('utf-8')
    req = urllib.request.Request(
        base_url + '/login',
        data=form,
        headers={'Content-Type': 'application/x-www-form-urlencoded'},
        method='POST'
    )
    opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler)
    try:
        with opener.open(req, timeout=ONLINE_TIMEOUT_SECONDS) as res:
            cookie = res.headers.get('Set-Cookie') or ''
            if cookie:
                return cookie.split(';', 1)[0]
    except urllib.error.HTTPError as e:
        cookie = e.headers.get('Set-Cookie') or ''
        if cookie:
            return cookie.split(';', 1)[0]
        raise
    return ''


def fetch_online_meta(cfg):
    base_url = cfg.get('base_url') or DEFAULT_ONLINE_URL
    teacher = cfg.get('teacher') or 'yeop'
    password = cfg.get('password') or ''
    status, res, _ = _http_request_json(
        f'{base_url}/api/{teacher}/meta?ts={int(time.time())}',
        None,
        headers={'X-SANDSU-PASSWORD': password},
        method='GET'
    )
    if not (200 <= status < 300) or not isinstance(res, dict) or res.get('ok') is False:
        raise RuntimeError(str(res))
    return res.get('meta') or {}


def download_online_payload(cfg):
    return _drive_read(cfg)


def fetch_remote_signal(cfg):
    marker = _sync_marker(_drive_read(cfg))
    if marker.get('source') != 'online':
        return 0
    revision = str(marker.get('revision') or '')
    return abs(hash(revision)) if revision else 0



def sync_latest_with_online():
    """On startup, apply only a Google Drive file explicitly saved online."""
    return poll_online_once(force=True)


def upload_payload_to_online(payload, skip_precheck=False):
    """Local auto-save: write the complete current file directly to Google Drive."""
    global _online_last_status
    cfg = load_online_config()
    if not cfg.get('enabled'):
        _online_last_status = {'ok': None, 'message': 'Google Drive 저장 꺼짐', 'uploaded_at': ''}
        return False
    try:
        _drive_write(cfg, payload, 'local')
        _online_last_status = {
            'ok': True,
            'message': 'Google Drive 저장됨',
            'uploaded_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        return True
    except Exception as e:
        _online_last_status = {
            'ok': False,
            'message': 'Google Drive 저장 실패: ' + str(e)[:160],
            'uploaded_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        return False

def _run_immediate_online_upload():
    global _online_timer, _online_latest_payload, _local_dirty
    try:
        while True:
            with _online_lock:
                payload = _online_latest_payload
                _online_latest_payload = None
            if payload is None:
                break
            upload_payload_to_online(payload)
    finally:
        with _online_lock:
            # If another save arrived after the final queue check, keep the
            # worker alive by starting one more pass instead of clearing dirty.
            if _online_latest_payload is not None:
                _online_timer = threading.Thread(
                    target=_run_immediate_online_upload,
                    daemon=True,
                    name='sandsu-online-save',
                )
                _online_timer.start()
            else:
                _online_timer = None
                _local_dirty = False


def queue_online_upload(payload):
    global _online_timer, _online_latest_payload, _local_dirty
    cfg = load_online_config()
    if not cfg.get('enabled'):
        return
    with _online_lock:
        _local_dirty = True
        _online_latest_payload = payload
        if _online_timer is not None and _online_timer.is_alive():
            return
        _online_timer = threading.Thread(
            target=_run_immediate_online_upload,
            daemon=True,
            name='sandsu-online-save',
        )
        _online_timer.start()

def get_remote_sync_state():
    local_payload = None
    try:
        local_payload = read_local_payload()
    except Exception:
        pass
    return {
        'revision': _remote_sync_revision,
        'version': int((local_payload or {}).get('version') or 0) if isinstance(local_payload, dict) else 0,
        'updated_at': str((local_payload or {}).get('updated_at') or '') if isinstance(local_payload, dict) else '',
        'status': dict(_online_last_status),
    }


def poll_online_once(force=False):
    """Check the Drive marker and import only an explicit online Save."""
    global _online_last_status, _remote_sync_revision
    cfg = load_online_config()
    if not cfg.get('enabled'):
        return False
    with _online_lock:
        busy = _local_dirty or (_online_timer is not None and _online_timer.is_alive()) or _online_latest_payload is not None
    if busy and not force:
        return False
    try:
        remote_payload = _drive_read(cfg)
        marker = _sync_marker(remote_payload)
        if marker.get('source') != 'online':
            return False
        revision = str(marker.get('revision') or '')
        saved_revision = str(cfg.get('last_online_revision') or '')
        if not revision or revision == saved_revision:
            return False
        cleaned = _clean_remote_payload(remote_payload)
        write_json_safely(cleaned)
        cfg['last_online_revision'] = revision
        save_online_config(cfg)
        with _remote_sync_lock:
            _remote_sync_revision += 1
        _online_last_status = {
            'ok': True,
            'message': '온라인 저장 내용을 Google Drive에서 반영함',
            'uploaded_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        return True
    except Exception as e:
        _online_last_status = {
            'ok': False,
            'message': 'Google Drive 확인 실패: ' + str(e)[:160],
            'uploaded_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        return False

def remote_poll_loop():
    while not _remote_sync_stop.wait(REMOTE_POLL_SECONDS):
        poll_online_once()



class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


class NoCacheHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def log_message(self, format, *args):
        # Keep packaged app quiet.
        return

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        clean_path = urlparse(self.path).path
        if clean_path in ('/', ''):
            self.send_response(302)
            self.send_header('Location', f'/{TARGET}?v=59_{int(datetime.now().timestamp())}')
            self.end_headers()
            return
        if clean_path == '/api/online-config':
            self._send_json(200, {'ok': True, 'config': public_online_config()})
            return
        if clean_path == '/api/online-status':
            self._send_json(200, {'ok': True, 'status': dict(_online_last_status)})
            return
        if clean_path == '/api/remote-sync-state':
            self._send_json(200, {'ok': True, **get_remote_sync_state()})
            return
        if clean_path == '/api/load':
            ensure_data_dirs()
            if not os.path.exists(DATA_FILE):
                self._send_json(200, {'ok': True, 'data': None})
                return
            try:
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self._send_json(200, {'ok': True, 'data': data})
            except Exception as e:
                self._send_json(500, {'ok': False, 'error': str(e)})
            return
        if clean_path == '/api/themes':
            ensure_data_dirs()
            try:
                files = []
                for name in os.listdir(THEMES_DIR):
                    if not name.lower().endswith('.css'):
                        continue
                    if '/' in name or '\\' in name or name.startswith('.'):
                        continue
                    path = os.path.join(THEMES_DIR, name)
                    if os.path.isfile(path):
                        files.append(name)
                files.sort(key=lambda x: (x != 'default.css', x.lower()))
                self._send_json(200, {'ok': True, 'files': files})
            except Exception as e:
                self._send_json(500, {'ok': False, 'error': str(e)})
            return
        if clean_path == '/api/ping':
            self._send_json(200, {'ok': True, 'target': TARGET})
            return
        if clean_path == '/api/shutdown':
            self._send_json(200, {'ok': True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        super().do_GET()

    def do_POST(self):
        clean_path = urlparse(self.path).path
        if clean_path == '/api/online-config':
            try:
                length = int(self.headers.get('Content-Length', '0') or '0')
                raw = self.rfile.read(length).decode('utf-8')
                payload = json.loads(raw) if raw else {}
                cfg = save_online_config(payload)
                self._send_json(200, {'ok': True, 'config': public_online_config()})
            except Exception as e:
                self._send_json(500, {'ok': False, 'error': str(e)})
            return
        if clean_path == '/api/online-sync-now':
            try:
                ok = sync_latest_with_online()
                self._send_json(200 if ok else 500, {'ok': ok, 'status': dict(_online_last_status)})
            except Exception as e:
                self._send_json(500, {'ok': False, 'error': str(e)})
            return
        if clean_path == '/api/online-upload-now':
            try:
                if os.path.exists(DATA_FILE):
                    with open(DATA_FILE, 'r', encoding='utf-8') as f:
                        payload = json.load(f)
                else:
                    payload = {}
                ok = upload_payload_to_online(payload)
                self._send_json(200 if ok else 500, {'ok': ok, 'status': dict(_online_last_status)})
            except Exception as e:
                self._send_json(500, {'ok': False, 'error': str(e)})
            return
        if clean_path == '/api/save':
            try:
                length = int(self.headers.get('Content-Length', '0') or '0')
                raw = self.rfile.read(length).decode('utf-8')
                payload = json.loads(raw) if raw else {}
                payload = normalize_local_payload(payload)
                write_json_safely(payload)
                queue_online_upload(payload)
                self._send_json(200, {'ok': True, 'updated_at': payload.get('updated_at'), 'version': payload.get('version')})
            except Exception as e:
                self._send_json(500, {'ok': False, 'error': str(e)})
            return
        self.send_error(404, 'Not Found')


if __name__ == '__main__':
    ensure_data_dirs()
    create_startup_backup_once()
    # Local is the master. Only apply a pending explicit online-save signal.
    sync_latest_with_online()
    print(f'Serving http://127.0.0.1:{PORT}/{TARGET}')
    print(f'Data file: {DATA_FILE}')
    print('Backup policy: startup once per day only; auto-save overwrites academy_data.json only.')
    print(f'Online config: {ONLINE_CONFIG_FILE}')
    threading.Thread(target=remote_poll_loop, daemon=True, name='sandsu-online-poll').start()
    with ReusableThreadingHTTPServer(('127.0.0.1', PORT), NoCacheHandler) as httpd:
        httpd.serve_forever()
