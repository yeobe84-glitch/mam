@echo off
cd /d "%~dp0"

taskkill /f /im python.exe >nul 2>&1
taskkill /f /im pythonw.exe >nul 2>&1

start "" pythonw.exe server_nocache_ui_exam_message_bookfocus_v59.py

timeout /t 2 >nul

start "" chrome.exe --app=http://127.0.0.1:8027/sandsu_attendance_ui_exam_message_bookfocus_v59.html?v=59a --start-maximized

exit
